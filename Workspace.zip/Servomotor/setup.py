from setuptools import setup, find_packages

setup(
    name="servomotor",
    version="0.1.0",
    packages=["servomotor"],  # explicitly list only your package
)